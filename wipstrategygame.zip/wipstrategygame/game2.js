BasicGame.Game2 = function(game) {

};

BasicGame.Game2.prototype = {

	create: function() {

	},
	
	update: function() {

	},
	
}